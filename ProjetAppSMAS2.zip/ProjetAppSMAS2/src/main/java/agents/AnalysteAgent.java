package agents;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

import Utils.pdfReader;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class AnalysteAgent extends Agent {

    private static final long serialVersionUID = 1L;

    
    private static final String API_URL =
            "https://api.groq.com/openai/v1/chat/completions";

    private static final String API_KEY =
    	      "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";
    private static final String MODEL =
            "openai/gpt-oss-120b";

    @Override
    protected void setup() {

        System.out.println("======================================");
        System.out.println("AnalysteAgent démarré");
        System.out.println("======================================");

        addBehaviour(new CyclicBehaviour() {

            @Override
            public void action() {

                ACLMessage msg = receive();

                if (msg == null) {
                    block();
                    return;
                }

                String message = msg.getContent();

                System.out.println();
                System.out.println("===== ANALYSTE AGENT =====");
                System.out.println("Message reçu : " + message);

                String cheminPDF = "";

                String[] parties = message.split(";");

                for (String partie : parties) {

                    partie = partie.trim();

                    if (partie.startsWith("PDF=")) {

                        cheminPDF =
                                partie.substring(4).trim();
                    }
                }

                if (cheminPDF.isEmpty()) {

                    System.out.println(
                            "ERREUR : aucun PDF reçu."
                    );

                    return;
                }

                System.out.println(
                        "PDF : " + cheminPDF
                );

                String contenu =
                        pdfReader.lirePDF(cheminPDF);

                if (contenu == null ||
                        contenu.trim().isEmpty()) {

                    System.out.println(
                            "ERREUR : impossible de lire le PDF."
                    );

                    return;
                }

                System.out.println(
                        "PDF lu avec succès."
                );

                System.out.println(
                        "Nombre de caractères : "
                        + contenu.length()
                );

                String analyse =
                        analyserAvecLLM(contenu);

                if (analyse == null ||
                        analyse.trim().isEmpty()) {

                    System.out.println(
                            "ERREUR : aucune analyse reçue."
                    );

                    return;
                }

                System.out.println();
                System.out.println(
                        "===== ANALYSE DU LLM ====="
                );

                System.out.println(analyse);

                ACLMessage response =
                        new ACLMessage(ACLMessage.INFORM);

                response.addReceiver(
                        new AID(
                                "RecommandationAgent",
                                AID.ISLOCALNAME
                        )
                );

                response.setContent(analyse);

                send(response);

                System.out.println(
                        "AnalysteAgent -> RecommandationAgent"
                );
            }
        });
    }

    private String analyserAvecLLM(String contenuPDF) {

        HttpURLConnection connection = null;

        try {

            int limite = 12000;

            String texte;

            if (contenuPDF.length() > limite) {

                texte =
                        contenuPDF.substring(0, limite);

            } else {

                texte = contenuPDF;
            }

            String prompt =
                    "Tu es un enseignant expert "
                    + "en informatique et en pédagogie.\n\n"

                    + "Analyse réellement le document "
                    + "de l'étudiant contenant un examen "
                    + "et ses réponses.\n\n"

                    + "Identifie les notions maîtrisées "
                    + "et surtout les notions mal maîtrisées.\n\n"

                    + "Une notion simplement présente dans "
                    + "le document n'est PAS automatiquement "
                    + "une faiblesse.\n\n"

                    + "Retourne exactement ce format :\n\n"

                    + "NIVEAU=...\n"

                    + "POINTS_FORTS="
                    + "notion1;notion2;notion3\n"

                    + "POINTS_FAIBLES="
                    + "notion1;notion2;notion3\n"

                    + "PRIORITES="
                    + "notion1;notion2;notion3\n\n"

                    + "Règles :\n"

                    + "- Répondre uniquement en français.\n"
                    + "- Ne pas inventer de notions.\n"
                    + "- Les points faibles doivent être "
                    + "basés sur les erreurs réellement observées.\n"
                    + "- Les priorités doivent correspondre "
                    + "aux points faibles.\n"
                    + "- Utiliser des noms courts et simples.\n\n"

                    + "===== DOCUMENT =====\n\n"
                    + texte;

            String json =
                    "{"
                    + "\"model\":\""
                    + MODEL
                    + "\","
                    + "\"messages\":["
                    + "{"
                    + "\"role\":\"user\","
                    + "\"content\":\""
                    + escapeJson(prompt)
                    + "\""
                    + "}"
                    + "],"
                    + "\"temperature\":0.2"
                    + "}";

            URL url =
                    new URL(API_URL);

            connection =
                    (HttpURLConnection)
                    url.openConnection();

            connection.setRequestMethod("POST");

            connection.setRequestProperty(
                    "Content-Type",
                    "application/json"
            );

            connection.setRequestProperty(
                    "Authorization",
                    "Bearer " + API_KEY
            );

            connection.setDoOutput(true);

            try (OutputStream output =
                         connection.getOutputStream()) {

                output.write(
                        json.getBytes(
                                StandardCharsets.UTF_8
                        )
                );
            }

            int code =
                    connection.getResponseCode();

            System.out.println(
                    "Code HTTP Groq : " + code
            );

            BufferedReader reader;

            if (code >= 200 && code < 300) {

                reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        connection.getInputStream(),
                                        StandardCharsets.UTF_8
                                )
                        );

            } else {

                reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        connection.getErrorStream(),
                                        StandardCharsets.UTF_8
                                )
                        );
            }

            StringBuilder resultat =
                    new StringBuilder();

            String ligne;

            while ((ligne = reader.readLine()) != null) {

                resultat.append(ligne);
            }

            reader.close();

            String reponse =
                    resultat.toString();

            if (code < 200 || code >= 300) {

                System.out.println(
                        "ERREUR GROQ :"
                );

                System.out.println(reponse);

                return null;
            }

            return extraireReponse(reponse);

        } catch (Exception e) {

            System.out.println(
                    "ERREUR LORS DE L'APPEL GROQ"
            );

            e.printStackTrace();

            return null;

        } finally {

            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private String extraireReponse(String json) {

        String recherche =
                "\"content\":\"";

        int debut =
                json.indexOf(recherche);

        if (debut == -1) {
            return json;
        }

        debut += recherche.length();

        StringBuilder resultat =
                new StringBuilder();

        boolean escape = false;

        for (int i = debut;
             i < json.length();
             i++) {

            char c = json.charAt(i);

            if (escape) {

                switch (c) {

                    case 'n':
                        resultat.append('\n');
                        break;

                    case 'r':
                        resultat.append('\r');
                        break;

                    case 't':
                        resultat.append('\t');
                        break;

                    case '"':
                        resultat.append('"');
                        break;

                    case '\\':
                        resultat.append('\\');
                        break;

                    default:
                        resultat.append(c);
                }

                escape = false;

            } else {

                if (c == '\\') {

                    escape = true;

                } else if (c == '"') {

                    break;

                } else {

                    resultat.append(c);
                }
            }
        }

        return resultat.toString().trim();
    }

    private String escapeJson(String texte) {

        return texte
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }
}