package agents;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class RecommandationAgent extends Agent {

    private static final long serialVersionUID = 1L;

    private static final String API_URL =
            "https://api.groq.com/openai/v1/chat/completions";

    private static final String API_KEY =
    	      "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";
    private static final String MODEL =
            "openai/gpt-oss-120b";
    @Override
    protected void setup() {

        System.out.println("======================================");
        System.out.println("RecommandationAgent démarré");
        System.out.println("======================================");

        addBehaviour(new CyclicBehaviour() {

            @Override
            public void action() {

                ACLMessage msg = receive();

                if (msg == null) {
                    block();
                    return;
                }

                String diagnostic = msg.getContent();

                System.out.println();
                System.out.println("===== RECOMMANDATION AGENT =====");
                System.out.println("Diagnostic reçu :");
                System.out.println(diagnostic);

                String recommandations =
                        genererRecommandations(diagnostic);

                if (recommandations == null ||
                        recommandations.trim().isEmpty()) {

                    System.out.println(
                            "ERREUR : aucune recommandation reçue."
                    );

                    return;
                }

                System.out.println();
                System.out.println(
                        "===== PLAN DE RÉVISION ====="
                );

                System.out.println(recommandations);

                /*
                 * On conserve le diagnostic original.
                 *
                 * C'est important car CoursAgent doit encore
                 * récupérer NIVEAU, POINTS_FORTS,
                 * POINTS_FAIBLES et PRIORITES.
                 */

                String messageFinal =
                        diagnostic
                        + "\n\n"
                        + recommandations;

                ACLMessage response =
                        new ACLMessage(ACLMessage.INFORM);

                response.addReceiver(
                        new AID(
                                "CoursAgent",
                                AID.ISLOCALNAME
                        )
                );

                response.setContent(messageFinal);

                send(response);

                System.out.println();
                System.out.println(
                        "RecommandationAgent -> CoursAgent"
                );
            }
        });
    }

    private String genererRecommandations(
            String diagnostic) {

        HttpURLConnection connection = null;

        try {

            String prompt =
                    "Tu es un conseiller pédagogique "
                    + "expert en informatique.\n\n"

                    + "Tu reçois le diagnostic réel "
                    + "d'un étudiant après analyse de "
                    + "son examen.\n\n"

                    + "Ton rôle est de transformer "
                    + "UNIQUEMENT ses points faibles "
                    + "en un plan de révision "
                    + "personnalisé.\n\n"

                    + "Ne refais pas l'analyse de "
                    + "l'examen.\n"

                    + "Ne crée pas de nouvelles "
                    + "faiblesses.\n"

                    + "Utilise uniquement les "
                    + "POINTS_FAIBLES présents "
                    + "dans le diagnostic.\n\n"

                    + "Pour chaque faiblesse, donne :\n"
                    + "- une priorité\n"
                    + "- un objectif précis\n"
                    + "- une action concrète\n\n"

                    + "Retourne exactement ce format :\n\n"

                    + "PLAN_DE_REVISION\n\n"

                    + "PRIORITE_1=...\n"
                    + "OBJECTIF_1=...\n"
                    + "ACTION_1=...\n\n"

                    + "PRIORITE_2=...\n"
                    + "OBJECTIF_2=...\n"
                    + "ACTION_2=...\n\n"

                    + "PRIORITE_3=...\n"
                    + "OBJECTIF_3=...\n"
                    + "ACTION_3=...\n\n"

                    + "PRIORITE_4=...\n"
                    + "OBJECTIF_4=...\n"
                    + "ACTION_4=...\n\n"

                    + "Règles :\n"
                    + "- français uniquement\n"
                    + "- ne pas inventer de faiblesse\n"
                    + "- les priorités correspondent "
                    + "aux points faibles\n"
                    + "- objectifs concrets\n"
                    + "- actions concrètes\n"
                    + "- maximum 4 priorités\n"
                    + "- pas de liens Internet\n"
                    + "- pas de certifications\n\n"

                    + "===== DIAGNOSTIC =====\n\n"
                    + diagnostic;

            String json =
                    "{"
                    + "\"model\":\""
                    + MODEL
                    + "\","
                    + "\"messages\":["
                    + "{"
                    + "\"role\":\"user\","
                    + "\"content\":\""
                    + escapeJson(prompt)
                    + "\""
                    + "}"
                    + "],"
                    + "\"temperature\":0.2"
                    + "}";

            URL url =
                    new URL(API_URL);

            connection =
                    (HttpURLConnection)
                    url.openConnection();

            connection.setRequestMethod("POST");

            connection.setRequestProperty(
                    "Content-Type",
                    "application/json"
            );

            connection.setRequestProperty(
                    "Authorization",
                    "Bearer " + API_KEY
            );

            connection.setDoOutput(true);

            try (OutputStream output =
                         connection.getOutputStream()) {

                output.write(
                        json.getBytes(
                                StandardCharsets.UTF_8
                        )
                );
            }

            int code =
                    connection.getResponseCode();

            System.out.println(
                    "Code HTTP Groq : " + code
            );

            BufferedReader reader;

            if (code >= 200 && code < 300) {

                reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        connection.getInputStream(),
                                        StandardCharsets.UTF_8
                                )
                        );

            } else {

                reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        connection.getErrorStream(),
                                        StandardCharsets.UTF_8
                                )
                        );
            }

            StringBuilder resultat =
                    new StringBuilder();

            String ligne;

            while ((ligne = reader.readLine()) != null) {
                resultat.append(ligne);
            }

            reader.close();

            String reponse =
                    resultat.toString();

            if (code < 200 || code >= 300) {

                System.out.println(
                        "ERREUR GROQ :"
                );

                System.out.println(reponse);

                return null;
            }

            return extraireReponse(reponse);

        } catch (Exception e) {

            System.out.println(
                    "ERREUR LORS DE L'APPEL GROQ"
            );

            e.printStackTrace();

            return null;

        } finally {

            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private String extraireReponse(String json) {

        String recherche =
                "\"content\":\"";

        int debut =
                json.indexOf(recherche);

        if (debut == -1) {
            return json;
        }

        debut += recherche.length();

        StringBuilder resultat =
                new StringBuilder();

        boolean escape = false;

        for (int i = debut;
             i < json.length();
             i++) {

            char c = json.charAt(i);

            if (escape) {

                switch (c) {

                    case 'n':
                        resultat.append('\n');
                        break;

                    case 'r':
                        resultat.append('\r');
                        break;

                    case 't':
                        resultat.append('\t');
                        break;

                    case '"':
                        resultat.append('"');
                        break;

                    case '\\':
                        resultat.append('\\');
                        break;

                    default:
                        resultat.append(c);
                }

                escape = false;

            } else {

                if (c == '\\') {

                    escape = true;

                } else if (c == '"') {

                    break;

                } else {

                    resultat.append(c);
                }
            }
        }

        return resultat.toString().trim();
    }

    private String escapeJson(String texte) {

        return texte
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }
}