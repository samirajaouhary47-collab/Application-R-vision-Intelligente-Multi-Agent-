
package agents;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.lang.acl.ACLMessage;

public class StudentAgent extends Agent {

    private static final long serialVersionUID = 1L;

    private static StudentAgent instance;

    private static String nomEtudiant = "";
    private static String cheminPDF = "";
    private static String dernierResultat = "";

    @Override
    protected void setup() {

        instance = this;

        System.out.println("======================================");
        System.out.println("StudentAgent démarré");
        System.out.println("======================================");

        addBehaviour(new CyclicBehaviour() {

            @Override
            public void action() {

                ACLMessage msg = receive();

                if (msg != null) {

                    dernierResultat = msg.getContent();

                    System.out.println();
                    System.out.println("===== RÉSULTAT FINAL =====");
                    System.out.println(dernierResultat);

                } else {

                    block();
                }
            }
        });
    }


    public static void setNomEtudiant(String nom) {

        nomEtudiant = nom;
    }


    public static void setCheminPDF(String chemin) {

        cheminPDF = chemin;
    }


    public static void lancerAnalyse() {

        if (instance == null) {

            System.out.println(
                    "ERREUR : StudentAgent n'est pas démarré."
            );

            return;
        }

        dernierResultat = "";

        instance.addBehaviour(
                new OneShotBehaviour() {

                    @Override
                    public void action() {

                        ACLMessage msg =
                                new ACLMessage(
                                        ACLMessage.REQUEST
                                );

                        msg.addReceiver(
                                new AID(
                                        "AnalysteAgent",
                                        AID.ISLOCALNAME
                                )
                        );

                        msg.setContent(
                                "Nom=" + nomEtudiant
                                + "; PDF=" + cheminPDF
                        );

                        instance.send(msg);

                        System.out.println();
                        System.out.println(
                                "StudentAgent -> AnalysteAgent"
                        );

                        System.out.println(
                                "PDF envoyé pour analyse."
                        );
                    }
                }
        );
    }


    public static String getDernierResultat() {

        return dernierResultat;
    }
}
 