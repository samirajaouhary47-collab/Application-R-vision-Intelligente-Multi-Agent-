
package agents;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class CoursAgent extends Agent {

	private static final String API_URL =
            "https://api.groq.com/openai/v1/chat/completions";

    private static final String API_KEY =
    	      "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";
    private static final String MODEL =
            "openai/gpt-oss-120b";

    @Override
    protected void setup() {

        System.out.println("======================================");
        System.out.println("CoursAgent démarré");
        System.out.println("======================================");

        addBehaviour(new CyclicBehaviour() {

            @Override
            public void action() {

                ACLMessage msg = receive();

                if (msg == null) {
                    block();
                    return;
                }

                String contenu =
                        msg.getContent();

                System.out.println();
                System.out.println(
                        "===== COURS AGENT ====="
                );

                System.out.println(
                        "Diagnostic + plan reçus."
                );

                String ressources =
                        genererRessources(contenu);

                if (ressources == null ||
                        ressources.trim().isEmpty()) {

                    System.out.println(
                            "ERREUR : aucune ressource générée."
                    );

                    return;
                }

                System.out.println();
                System.out.println(
                        "===== CONTENU PERSONNALISÉ ====="
                );

                System.out.println(ressources);

                String niveau =
                        extraire(
                                contenu,
                                "NIVEAU="
                        );

                String pointsForts =
                        extraire(
                                contenu,
                                "POINTS_FORTS="
                        );

                String pointsFaibles =
                        extraire(
                                contenu,
                                "POINTS_FAIBLES="
                        );

                String priorites =
                        extraire(
                                contenu,
                                "PRIORITES="
                        );

                String resultat =

                        "===== DIAGNOSTIC PERSONNALISÉ =====\n\n"

                        + "Niveau général : "
                        + niveau
                        + "\n\n"

                        + "POINTS FORTS\n"
                        + formaterListe(pointsForts)
                        + "\n\n"

                        + "POINTS FAIBLES\n"
                        + formaterListe(pointsFaibles)
                        + "\n\n"

                        + "PRIORITÉS DE RÉVISION\n"
                        + formaterListe(priorites)
                        + "\n\n"

                        + "PLAN DE RÉVISION\n\n"

                        + extrairePlan(contenu)
                        + "\n\n"

                        + ressources;

                System.out.println();
                System.out.println(
                        "===== RÉSULTAT FINAL ====="
                );

                System.out.println(resultat);

                ACLMessage response =
                        new ACLMessage(
                                ACLMessage.INFORM
                        );

                response.addReceiver(
                        new AID(
                                "StudentAgent",
                                AID.ISLOCALNAME
                        )
                );

                response.setContent(resultat);

                send(response);

                System.out.println();
                System.out.println(
                        "CoursAgent -> StudentAgent"
                );
            }
        });
    }

    private String genererRessources(
            String diagnosticEtPlan) {

        HttpURLConnection connection = null;

        try {

            String prompt =

                    "Tu es un professeur expert "
                    + "en informatique et en pédagogie.\n\n"

                    + "Tu reçois le diagnostic réel "
                    + "d'un étudiant ainsi que son "
                    + "plan de révision personnalisé.\n\n"

                    + "Ton rôle est de produire "
                    + "des ressources pédagogiques "
                    + "PERSONNALISÉES.\n\n"

                    + "Pour chaque faiblesse importante, "
                    + "fais trois choses :\n\n"

                    + "1. COURS : explique précisément "
                    + "la notion que l'étudiant "
                    + "maîtrise mal.\n\n"

                    + "2. EXERCICE : propose un exercice "
                    + "directement lié à cette faiblesse "
                    + "et à l'erreur détectée.\n\n"

                    + "3. QUIZ : propose 3 questions "
                    + "courtes permettant de vérifier "
                    + "si l'étudiant a corrigé "
                    + "sa difficulté.\n\n"

                    + "IMPORTANT :\n"
                    + "- utilise uniquement les notions "
                    + "présentes dans le diagnostic\n"
                    + "- ne crée pas de nouvelles "
                    + "faiblesses\n"
                    + "- personnalise le contenu selon "
                    + "les erreurs détectées\n"
                    + "- évite les cours génériques\n"
                    + "- explique pourquoi la notion "
                    + "est importante\n"
                    + "- les exercices doivent être "
                    + "concrets\n"
                    + "- les quiz doivent tester "
                    + "la compréhension\n"
                    + "- français uniquement\n\n"

                    + "Retourne exactement cette structure :\n\n"

                    + "COURS_PERSONNALISÉS\n\n"

                    + "NOTION_1=...\n"
                    + "EXPLICATION_1=...\n"
                    + "POURQUOI_1=...\n\n"

                    + "NOTION_2=...\n"
                    + "EXPLICATION_2=...\n"
                    + "POURQUOI_2=...\n\n"

                    + "EXERCICES_PERSONNALISÉS\n\n"

                    + "EXERCICE_1=...\n"
                    + "OBJECTIF_EXERCICE_1=...\n\n"

                    + "EXERCICE_2=...\n"
                    + "OBJECTIF_EXERCICE_2=...\n\n"

                    + "QUIZ_PERSONNALISÉS\n\n"

                    + "QUESTION_1=...\n"
                    + "QUESTION_2=...\n"
                    + "QUESTION_3=...\n"
                    + "QUESTION_4=...\n"
                    + "QUESTION_5=...\n\n"

                    + "Ne donne pas les réponses "
                    + "du quiz.\n\n"

                    + "===== DIAGNOSTIC ET PLAN =====\n\n"

                    + diagnosticEtPlan;

            String json =
                    "{"
                    + "\"model\":\""
                    + MODEL
                    + "\","
                    + "\"messages\":["
                    + "{"
                    + "\"role\":\"user\","
                    + "\"content\":\""
                    + escapeJson(prompt)
                    + "\""
                    + "}"
                    + "],"
                    + "\"temperature\":0.3"
                    + "}";

            URL url =
                    new URL(API_URL);

            connection =
                    (HttpURLConnection)
                    url.openConnection();

            connection.setRequestMethod("POST");

            connection.setRequestProperty(
                    "Content-Type",
                    "application/json"
            );

            connection.setRequestProperty(
                    "Authorization",
                    "Bearer " + API_KEY
            );

            connection.setDoOutput(true);

            try (OutputStream output =
                         connection.getOutputStream()) {

                output.write(
                        json.getBytes(
                                StandardCharsets.UTF_8
                        )
                );
            }

            int code =
                    connection.getResponseCode();

            System.out.println(
                    "Code HTTP Groq : " + code
            );

            BufferedReader reader;

            if (code >= 200 && code < 300) {

                reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        connection.getInputStream(),
                                        StandardCharsets.UTF_8
                                )
                        );

            } else {

                reader =
                        new BufferedReader(
                                new InputStreamReader(
                                        connection.getErrorStream(),
                                        StandardCharsets.UTF_8
                                )
                        );
            }

            StringBuilder resultat =
                    new StringBuilder();

            String ligne;

            while ((ligne = reader.readLine()) != null) {
                resultat.append(ligne);
            }

            reader.close();

            String reponse =
                    resultat.toString();

            if (code < 200 || code >= 300) {

                System.out.println(
                        "ERREUR GROQ :"
                );

                System.out.println(reponse);

                return null;
            }

            return extraireReponse(reponse);

        } catch (Exception e) {

            System.out.println(
                    "ERREUR LORS DE L'APPEL GROQ"
            );

            e.printStackTrace();

            return null;

        } finally {

            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private String extraire(
            String texte,
            String cle) {

        int debut =
                texte.indexOf(cle);

        if (debut == -1) {
            return "";
        }

        debut += cle.length();

        int fin =
                texte.indexOf(
                        "\n",
                        debut
                );

        if (fin == -1) {
            fin = texte.length();
        }

        return texte
                .substring(
                        debut,
                        fin
                )
                .trim();
    }

    private String extrairePlan(
            String texte) {

        int debut =
                texte.indexOf(
                        "PLAN_DE_REVISION"
                );

        if (debut == -1) {
            return "- Aucun plan disponible.";
        }

        return texte
                .substring(debut)
                .trim();
    }

    private String formaterListe(
            String texte) {

        if (texte == null ||
                texte.trim().isEmpty()) {

            return "- Aucun élément";
        }

        StringBuilder resultat =
                new StringBuilder();

        String[] elements =
                texte.split(";");

        for (String element : elements) {

            element =
                    element.trim();

            if (!element.isEmpty()) {

                resultat.append("- ");
                resultat.append(element);
                resultat.append("\n");
            }
        }

        return resultat
                .toString()
                .trim();
    }

    private String extraireReponse(
            String json) {

        String recherche =
                "\"content\":\"";

        int debut =
                json.indexOf(recherche);

        if (debut == -1) {
            return json;
        }

        debut += recherche.length();

        StringBuilder resultat =
                new StringBuilder();

        boolean escape = false;

        for (int i = debut;
             i < json.length();
             i++) {

            char c = json.charAt(i);

            if (escape) {

                switch (c) {

                    case 'n':
                        resultat.append('\n');
                        break;

                    case 'r':
                        resultat.append('\r');
                        break;

                    case 't':
                        resultat.append('\t');
                        break;

                    case '"':
                        resultat.append('"');
                        break;

                    case '\\':
                        resultat.append('\\');
                        break;

                    default:
                        resultat.append(c);
                }

                escape = false;

            } else {

                if (c == '\\') {

                    escape = true;

                } else if (c == '"') {

                    break;

                } else {

                    resultat.append(c);
                }
            }
        }

        return resultat
                .toString()
                .trim();
    }

    private String escapeJson(
            String texte) {

        return texte
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "\\r")
                .replace("\n", "\\n");
    }
}
