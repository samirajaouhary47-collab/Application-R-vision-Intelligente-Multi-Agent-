
package gui;

import javax.swing.*;
import java.awt.*;

import agents.StudentAgent;

public class InterfacePrincipale extends JFrame {

    private static final long serialVersionUID = 1L;

    private JTextField nomField;
    private JTextField pdfField;
    private JTextArea resultatArea;

    public InterfacePrincipale() {

        setTitle("Révision Intelligente Multi-Agent");

        // Taille initiale
        setSize(850, 650);

        setMinimumSize(new Dimension(700, 550));

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);

        // =====================================================
        // PANEL PRINCIPAL
        // =====================================================

        JPanel panel =
            new JPanel(new BorderLayout(10, 10));

        panel.setBorder(
            BorderFactory.createEmptyBorder(
                15, 20, 15, 20
            )
        );

        // =====================================================
        // TITRE
        // =====================================================

        JLabel titre =
            new JLabel(
                "RÉVISION INTELLIGENTE MULTI-AGENT",
                SwingConstants.CENTER
            );

        titre.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                22
            )
        );

        titre.setBorder(
            BorderFactory.createEmptyBorder(
                0, 0, 10, 0
            )
        );

        panel.add(
            titre,
            BorderLayout.NORTH
        );

        // =====================================================
        // PARTIE SUPÉRIEURE : FORMULAIRE
        // =====================================================

        JPanel formulaire =
            new JPanel(
                new GridBagLayout()
            );

        formulaire.setBorder(
            BorderFactory.createTitledBorder(
                "Informations de l'étudiant"
            )
        );

        GridBagConstraints gbc =
            new GridBagConstraints();

        gbc.insets =
            new Insets(5, 8, 5, 8);

        gbc.fill =
            GridBagConstraints.HORIZONTAL;

        // -----------------------------------------------------
        // NOM
        // -----------------------------------------------------

        JLabel nomLabel =
            new JLabel("Nom étudiant :");

        nomLabel.setFont(
            new Font(
                "Arial",
                Font.PLAIN,
                14
            )
        );

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0;

        formulaire.add(
            nomLabel,
            gbc
        );

        nomField =
            new JTextField();

        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;

        formulaire.add(
            nomField,
            gbc
        );

        // -----------------------------------------------------
        // PDF
        // -----------------------------------------------------

        JLabel pdfLabel =
            new JLabel("Examen PDF :");

        pdfLabel.setFont(
            new Font(
                "Arial",
                Font.PLAIN,
                14
            )
        );

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;

        formulaire.add(
            pdfLabel,
            gbc
        );

        pdfField =
            new JTextField();

        pdfField.setEditable(false);

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1.0;

        formulaire.add(
            pdfField,
            gbc
        );

        // -----------------------------------------------------
        // BOUTON CHOISIR PDF
        // -----------------------------------------------------

        JButton choisirButton =
            new JButton("Choisir PDF");

        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.weightx = 0;

        formulaire.add(
            choisirButton,
            gbc
        );

        // -----------------------------------------------------
        // BOUTON ANALYSER
        // -----------------------------------------------------

        JButton analyserButton =
            new JButton(
                "ANALYSER L'EXAMEN"
            );

        analyserButton.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                14
            )
        );

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 3;
        gbc.weightx = 0;

        gbc.anchor =
            GridBagConstraints.CENTER;

        formulaire.add(
            analyserButton,
            gbc
        );

        // =====================================================
        // AJOUT DU FORMULAIRE
        // =====================================================

        panel.add(
            formulaire,
            BorderLayout.CENTER
        );

        // =====================================================
        // RÉSULTATS
        // =====================================================

        JLabel resultatLabel =
            new JLabel(
                "Résultats de l'analyse"
            );

        resultatLabel.setFont(
            new Font(
                "Arial",
                Font.BOLD,
                16
            )
        );

        resultatArea =
            new JTextArea();

        resultatArea.setEditable(false);

        resultatArea.setLineWrap(true);

        resultatArea.setWrapStyleWord(true);

        resultatArea.setFont(
            new Font(
                "Arial",
                Font.PLAIN,
                14
            )
        );

        resultatArea.setText(
            "Aucun examen analysé pour le moment."
        );

        resultatArea.setMargin(
            new Insets(10, 10, 10, 10)
        );

        JScrollPane scroll =
            new JScrollPane(
                resultatArea
            );

        // Toujours afficher la barre verticale si nécessaire
        scroll.setVerticalScrollBarPolicy(
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED
        );

        scroll.setHorizontalScrollBarPolicy(
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
        );

        JPanel resultatPanel =
            new JPanel(
                new BorderLayout(5, 5)
            );

        resultatPanel.setBorder(
            BorderFactory.createTitledBorder(
                "Résultat"
            )
        );

        resultatPanel.add(
            resultatLabel,
            BorderLayout.NORTH
        );

        resultatPanel.add(
            scroll,
            BorderLayout.CENTER
        );

        // =====================================================
        // IMPORTANT :
        // LES RÉSULTATS PRENNENT LA GRANDE PARTIE
        // =====================================================

        panel.add(
            resultatPanel,
            BorderLayout.SOUTH
        );

        // Donner une hauteur raisonnable à la zone résultat
        resultatPanel.setPreferredSize(
            new Dimension(
                0,
                360
            )
        );

        // =====================================================
        // CHOISIR PDF
        // =====================================================

        choisirButton.addActionListener(e -> {

            JFileChooser chooser =
                new JFileChooser();

            int resultat =
                chooser.showOpenDialog(this);

            if (resultat ==
                JFileChooser.APPROVE_OPTION) {

                pdfField.setText(
                    chooser
                        .getSelectedFile()
                        .getAbsolutePath()
                );
            }
        });

        // =====================================================
        // ANALYSER
        // =====================================================

        analyserButton.addActionListener(e -> {

            String nom =
                nomField.getText().trim();

            String pdf =
                pdfField.getText().trim();

            // -------------------------------------------------
            // Vérification
            // -------------------------------------------------

            if (nom.isEmpty() ||
                pdf.isEmpty()) {

                JOptionPane.showMessageDialog(
                    this,
                    "Veuillez saisir le nom et choisir un PDF.",
                    "Information",
                    JOptionPane.WARNING_MESSAGE
                );

                return;
            }

            // -------------------------------------------------
            // Affichage pendant l'analyse
            // -------------------------------------------------

            resultatArea.setText(
                "===== ANALYSE EN COURS =====\n\n"
                + "Étudiant : "
                + nom
                + "\n\n"
                + "Examen : "
                + pdf
                + "\n\n"
                + "StudentAgent transmet le PDF...\n"
                + "AnalysteAgent lit le PDF...\n"
                + "LLM analyse les réponses...\n"
                + "Génération des recommandations...\n\n"
                + "Veuillez patienter..."
            );

            // -------------------------------------------------
            // Communication avec StudentAgent
            // -------------------------------------------------

            StudentAgent.setNomEtudiant(nom);

            StudentAgent.setCheminPDF(pdf);

            StudentAgent.lancerAnalyse();

            // -------------------------------------------------
            // Attendre le résultat
            // -------------------------------------------------

            Timer timer =
                new Timer(
                    500,
                    null
                );

            timer.addActionListener(event -> {

                String resultat =
                    StudentAgent.getDernierResultat();

                if (resultat != null &&
                    !resultat.isEmpty()) {

                    resultatArea.setText(
                        "===== RÉSULTAT DE L'ANALYSE =====\n\n"
                        + "Étudiant : "
                        + nom
                        + "\n\n"
                        + resultat
                    );

                    // Retour au début du résultat
                    resultatArea.setCaretPosition(0);

                    timer.stop();
                }
            });

            timer.start();
        });

        // =====================================================
        // FINALISATION
        // =====================================================

        setContentPane(panel);
    }

    // =========================================================
    // MAIN
    // =========================================================

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {

            InterfacePrincipale fenetre =
                new InterfacePrincipale();

            fenetre.setVisible(true);
        });
    }
}
