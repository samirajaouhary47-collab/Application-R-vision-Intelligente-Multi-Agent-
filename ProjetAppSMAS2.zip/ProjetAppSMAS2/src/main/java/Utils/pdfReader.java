package Utils;

import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class pdfReader {

    public static String lirePDF(String chemin) {

        try {

            File fichier = new File(chemin);

            PDDocument document =
                PDDocument.load(fichier);

            PDFTextStripper stripper =
                new PDFTextStripper();

            String texte =
                stripper.getText(document);

            document.close();

            return texte;

        } catch (Exception e) {

            e.printStackTrace();

            return null;
        }
    }
}
