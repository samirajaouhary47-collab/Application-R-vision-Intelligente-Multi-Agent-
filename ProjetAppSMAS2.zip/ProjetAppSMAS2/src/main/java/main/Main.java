
package main;

import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;

public class Main {

    public static AgentContainer container;

    public static void main(String[] args) {

        try {

            // =========================
            // CREATION DU RUNTIME JADE
            // =========================

            Runtime runtime = Runtime.instance();

            // Création du profil JADE
            Profile profile = new ProfileImpl();

            // Activer l'interface graphique JADE
            profile.setParameter(
                Profile.GUI,
                "true"
            );

            // Création du Main Container
            container =
                runtime.createMainContainer(profile);

            System.out.println(
                "===== Main Container démarré ====="
            );

            // =========================
            // CREATION DES AGENTS
            // =========================

            AgentController student =
                container.createNewAgent(
                    "StudentAgent",
                    "agents.StudentAgent",
                    null
                );

            AgentController analyste =
                container.createNewAgent(
                    "AnalysteAgent",
                    "agents.AnalysteAgent",
                    null
                );

            AgentController recommandation =
                container.createNewAgent(
                    "RecommandationAgent",
                    "agents.RecommandationAgent",
                    null
                );

            AgentController cours =
                container.createNewAgent(
                    "CoursAgent",
                    "agents.CoursAgent",
                    null
                );

            // =========================
            // DEMARRAGE DES AGENTS
            // =========================

            student.start();

            analyste.start();

            recommandation.start();

            cours.start();

            System.out.println(
                "===== Tous les agents sont démarrés ====="
            );

            // =========================
            // LANCEMENT DE L'INTERFACE
            // =========================

            javax.swing.SwingUtilities.invokeLater(() -> {

                gui.InterfacePrincipale fenetre =
                    new gui.InterfacePrincipale();

                fenetre.setVisible(true);
            });

            System.out.println(
                "===== SMA Révision Intelligente lancé ====="
            );

        } catch (Exception e) {

            System.out.println(
                "ERREUR lors du démarrage du SMA :"
            );

            e.printStackTrace();
        }
    }
}

